package com.example.digitalstethescope;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.Menu;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.shadow.ShadowDrawableWrapper;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.Viewport;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.Random;

public class MainActivity extends AppCompatActivity {


    DrawerLayout drawerLayout;
    NavigationView navigationView;

    Toolbar toolbar;

    GraphView graphView;
    int y=0;

//    private LineGraphSeries<DataPoint> series;
    private static final Random RANDOM = new Random();
    private int lastX = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        drawerLayout = findViewById(R.id.drawerlayout);
        navigationView = findViewById(R.id.navigationview);
        toolbar = findViewById(R.id.toolbar);
//        graphView = findViewById(R.id.graph);

//        series = new LineGraphSeries<>();
//        graphView.addSeries(series);
//

//
//        addEntry();

        GraphView graph = (GraphView) findViewById(R.id.graph);
        Viewport viewport = graph.getViewport();
        viewport.setXAxisBoundsManual(true);
        viewport.setYAxisBoundsManual(true);
        viewport.setMinX(0);
        viewport.setMaxX(20);
        viewport.setMinY(0);
        viewport.setMaxY(10);
        viewport.setScrollable(true);
        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(new DataPoint[] {
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 4),
                new DataPoint(lastX++, 6),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 2),
                new DataPoint(lastX++, 8),
                new DataPoint(lastX++, 3),
                new DataPoint(lastX++, 6),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 6),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 4),
                new DataPoint(lastX++, 6),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 2),
                new DataPoint(lastX++, 8),
                new DataPoint(lastX++, 3),
                new DataPoint(lastX++, 6),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 5),
                new DataPoint(lastX++, 6),
                new DataPoint(lastX++, 5)


        });
        graph.addSeries(series);



        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_open, R.string.navigation_close);

        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();


        //to put cutom menu icon
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_side_menu);




    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                for(int i = 0; i < 100; i++){
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            addEntry();
//                        }
//                    });
//
//                    try {
//                        Thread.sleep(600);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        }).start();
//    }

//    private void addEntry(){
//        series.appendData(new DataPoint(lastX++, 5), false, 10);
//        series.appendData(new DataPoint(lastX++, 5), false, 10);
//        series.appendData(new DataPoint(lastX++, 4), false, 10);
//        series.appendData(new DataPoint(lastX++, 6), false, 10);
//        series.appendData(new DataPoint(lastX++, 5), false, 10);
//        series.appendData(new DataPoint(lastX++, 5), false, 10);
//        series.appendData(new DataPoint(lastX++, 2), false, 10);
//        series.appendData(new DataPoint(lastX++, 8), false, 10);
//        series.appendData(new DataPoint(lastX++, 3), false, 10);
//        series.appendData(new DataPoint(lastX++, 6), false, 10);
//        series.appendData(new DataPoint(lastX++, 5), false, 10);
//        series.appendData(new DataPoint(lastX++, 5), false, 10);
//        series.appendData(new DataPoint(lastX++, 6), false, 10);
//        series.appendData(new DataPoint(lastX++, 5), false, 10);
//        series.appendData(new DataPoint(lastX++, 5), false, 10);
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;
    }

}