package com.example.digitalstethescope;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Splashscreen extends AppCompatActivity {

    //duration for splash screen
    public static int SPLASH_SCREEN = 4000;

    //Variables
    Animation topanim, bottomanim, zoomanimation;
    ImageView logoimage;
    TextView text1, text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);


        //Animations
        topanim = AnimationUtils.loadAnimation(this, R.anim.top_animation);
        bottomanim = AnimationUtils.loadAnimation(this, R.anim.bottom_animation);
        zoomanimation = AnimationUtils.loadAnimation(this, R.anim.zoomanimation);


        //hooks
        logoimage = findViewById(R.id.logo);
        logoimage.startAnimation(zoomanimation);
        text1 = findViewById(R.id.text1);
        text1.setAnimation(topanim);
        text2 = findViewById(R.id.text2);
        text2.setAnimation(topanim);


        //after animation is completed going to next activity
        new Handler().postDelayed(() -> {

            Intent intent = new Intent(Splashscreen.this, Enterotpscreen.class);
            startActivity(intent);
            finish();

        },SPLASH_SCREEN);
    }
}